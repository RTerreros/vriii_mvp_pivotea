--
--
{{
config(
materialized='table'
)
}}
--
--
select 
RESP.* 
from 
{{ source('surveymonkey', 'RESPONSE_ANSWER') }} as RESP
INNER JOIN
{{ source('surveymonkey', 'QUESTION_HISTORY') }} AS QUESTION
ON RESP.QUESTION_ID = QUESTION.ID
INNER JOIN
{{ source('surveymonkey', 'SURVEY_PAGE_HISTORY') }} AS PAGE
ON QUESTION.SURVEY_PAGE_ID = PAGE.ID
INNER JOIN
{{ source('surveymonkey', 'SURVEY_HISTORY') }} AS SURVEY
ON SURVEY.ID = PAGE.SURVEY_ID
where 
survey.title in
('Pivotea: Trazando mi futuro','Registro - Pivotea')
and question._FIVETRAN_ACTIVE=TRUE
and page._FIVETRAN_ACTIVE=TRUE
and survey._FIVETRAN_ACTIVE=TRUE




