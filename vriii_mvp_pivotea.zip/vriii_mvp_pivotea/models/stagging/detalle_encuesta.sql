--
--
{{
config(
materialized='table'
)
}}
--
--
select 
COLLECTOR.ID AS ID,
COLLECTOR.SURVEY_ID AS SURVEY_ID,
COLLECTOR.STATUS AS STATUS,
COLLECTOR.URL AS URL,
COLLECTOR._FIVETRAN_SYNCED AS _FIVETRAN_SYNCED
from {{ source('surveymonkey', 'COLLECTOR') }}  as collector
inner join 
{{ source('surveymonkey', 'SURVEY_HISTORY') }} as survey
on collector.survey_id = survey.id 
where 
survey.title in ('Pivotea: Trazando mi futuro','Registro - Pivotea')
and survey._fivetran_active=TRUE