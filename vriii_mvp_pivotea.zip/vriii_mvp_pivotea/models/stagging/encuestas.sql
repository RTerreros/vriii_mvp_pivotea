--
--
{{
config(
materialized='table'
)
}}
--
--
select
    *
from
    {{ source('surveymonkey', 'SURVEY_HISTORY') }} as ab
where
 ab._fivetran_active=TRUE and ab.title in 
('Pivotea: Trazando mi futuro','Registro - Pivotea')