--
{{
config(
materialized='table'
)
}}
--
--
Select 
page.id as id_page,
survey.id as survey_id,
page.title as title,
page.position,
page.description,
page._fivetran_synced as _fivetran_synced
from {{ source('surveymonkey', 'SURVEY_PAGE_HISTORY') }} as page
inner join
{{ source('surveymonkey', 'SURVEY_HISTORY') }}  as survey
on page.survey_id = survey.id 
where 
survey.title in
('Pivotea: Trazando mi futuro','Registro - Pivotea')
and  survey._fivetran_active=TRUE
and page._FIVETRAN_ACTIVE=TRUE