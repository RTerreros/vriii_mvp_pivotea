--
--
{{
config(
materialized='table'
)
}}
--
--
select 
resp_page.* 
from 
{{ source('surveymonkey', 'RESPONSE_PAGE') }}  as RESP_PAGE
inner join
{{ source('surveymonkey', 'RESPONSE_HISTORY') }}  as RESPONSES
on responses.id = resp_page.response_id
inner join 
{{ source('surveymonkey', 'SURVEY_HISTORY') }} as survey
on responses.survey_id = survey.id 
where 
survey.title in ('Pivotea: Trazando mi futuro','Registro - Pivotea')
and 
survey._fivetran_active=TRUE 
and responses._fivetran_active=TRUE






