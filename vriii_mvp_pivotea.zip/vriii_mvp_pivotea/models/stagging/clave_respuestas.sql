--
--
{{
config(
materialized='table'
)
}}
--
--
select 
responses.* from 
{{ source('surveymonkey', 'RESPONSE_HISTORY') }}  as RESPONSES
inner join 
{{ source('surveymonkey', 'SURVEY_HISTORY') }} as survey
on responses.survey_id = survey.id 
where 
survey.title in ('Pivotea: Trazando mi futuro','Registro - Pivotea')
and 
survey._fivetran_active=TRUE and responses._fivetran_active=TRUE


