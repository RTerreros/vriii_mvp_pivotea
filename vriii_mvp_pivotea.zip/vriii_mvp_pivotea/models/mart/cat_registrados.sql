--
--
{{
config(
materialized='table'
)
}}
--
--



select 
ID_RESPUESTA as ID_REGISTRO,
NOMBRE,
PRIMERAPELLIDO,
SEGUNDOAPELLIDO,
CORREO,
LUGAR,
GENERO,
FECHA_NAC,
TELEFONO,
SITUACION,
CALADERO,
ESTATUS_RESPUESTA,
to_date(fecha) as FECHA
from 
{{ ref('tfr_registro_usuarios') }} 