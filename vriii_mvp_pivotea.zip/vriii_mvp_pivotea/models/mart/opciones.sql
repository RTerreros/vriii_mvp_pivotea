--
--
{{
config(
materialized='table'
)
}}
--
--

select 
id as id_opcion,
clave_pregunta as id_pregunta,
opcion
from 
{{ ref('tfr_preguntas_opc') }}