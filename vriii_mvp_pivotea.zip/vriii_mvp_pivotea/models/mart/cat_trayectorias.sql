--
--
{{
config(
materialized='table'
)
}}
--
--

select 
RENGLON_ID AS ID_TRAYECTORIA,
ID_PAGINA,
RENGLON AS TRAYECTORIA,
POSICION_RENGLON AS POSICION,
case when TITULO_PAGINA = 'Ingeniería y Tecnología'  then 'Ingeniería - Tecnología' else TITULO_PAGINA end AS AREA
from 
{{ ref('tfr_trayectorias') }} 