--
--
{{
config(
materialized='table'
)
}}
--
--



select 
res.id_pagina,
res.id_pregunta,
res.id_respuesta,
res.opcion_respuesta,
tra.id_trayectoria as id_renglon_tray,
caty.id_trayectoria,
caty.trayectoria,
tra.trayectoria as opcion,
area.area,
opc.opcion as score,
res.fecha
from {{ ref('respuestas') }} res
inner join {{ ref('rel_tray_puntaje') }} tra
on tra.id_pagina = res.id_pagina
and tra.id_trayectoria = res.renglon_id
inner join {{ ref('rel_area_usuario') }} area
on area.id_pagina = res.id_pagina
inner join {{ ref('cat_trayectorias') }} caty
on caty.area = area.area 
and caty.posicion = tra.posicion
and area.id_respuesta = res.id_respuesta
inner join {{ ref('opciones') }} as opc
on opc.id_opcion = res.opcion_respuesta