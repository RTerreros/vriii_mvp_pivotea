


select correo,trayectoria,id_trayectoria,area,id_area,puntaje,
ROW_NUMBER() OVER(PARTITION BY correo ORDER BY puntaje DESC) AS top_posicion
from
{{ ref('trayectorias_usuarios') }}
