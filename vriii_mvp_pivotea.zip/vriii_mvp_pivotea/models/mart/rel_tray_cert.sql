--
--
{{
config(
materialized='table'
)
}}
--
--

select * 
from 
{{ ref('tfr_rel_tray_recom') }}