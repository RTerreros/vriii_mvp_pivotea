--
--
{{
config(
materialized='table'
)
}}
--
--
select 
resp.ID_ENCUESTA,
area.ID_PAGINA,
resp.ID_RESPUESTA,
OPCION_RESPUESTA,
ID_OPCION,
area,
OPCION,
POSICION,
titulo_pagina
from 
{{ ref('respuestas') }} as resp
inner join
{{ ref('cat_areas') }} 
 as area
on 
resp.id_pregunta = area.id_pregunta
and 
area.id_opcion = resp.opcion_respuesta