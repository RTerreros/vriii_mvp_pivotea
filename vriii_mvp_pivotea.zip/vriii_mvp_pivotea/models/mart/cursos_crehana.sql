--
--
{{
config(
materialized='table'
)
}}
--
--

select * 
from 
{{ ref('tfr_cursos_crehana') }}