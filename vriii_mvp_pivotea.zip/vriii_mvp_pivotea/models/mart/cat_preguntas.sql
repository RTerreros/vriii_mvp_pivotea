--
--
{{
config(
materialized='table'
)
}}
--
--


select 
clave_pregunta as ID_PREGUNTA,
ID_ENCUESTA,
ID_PAGINA,
PREGUNTA,
case when opciones is null then 'SIN OPCIONES' else 'CON OPCIONES' END as TIPO_RESPUESTA
from 
{{ ref('trf_tmp_preguntas') }}