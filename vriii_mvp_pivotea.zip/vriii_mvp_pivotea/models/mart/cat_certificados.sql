--
--
{{
config(
materialized='table'
)
}}
--
--

select * 
from 
{{ ref('tfr_recomendaciones') }}