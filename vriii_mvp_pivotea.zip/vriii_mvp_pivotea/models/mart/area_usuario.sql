



select usuario.correo,
area,
opcion 
from {{ ref('rel_area_usuario') }} as area
inner join {{ ref('cat_usuarios') }} as usuario
on area.id_respuesta = usuario.id_respuesta
