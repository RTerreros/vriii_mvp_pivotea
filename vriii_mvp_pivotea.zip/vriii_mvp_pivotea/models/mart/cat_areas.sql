--
--
{{
config(
materialized='table'
)
}}
--
--

--select 
--ID_PAGE as ID_PAGINA,
--TITLE AS AREA,
--TO_DATE(_fivetran_synced) AS FECHA
--from 
--{{ ref('paginas_encuestas') }} as page
--where 
--page.survey_id=411256991 
--and 
--page.position not in (1,10)
--order by
---page.position


WITH 
PR15 
AS (
select * from {{ ref('tfr_preguntas_opc') }}
where clave_pregunta in (171702571)
),
PR14 
AS (
select * from {{ ref('tfr_preguntas_opc') }}
where clave_pregunta in (171702494)
),
PAG
as
(
select 
ROW_NUMBER() OVER (ORDER BY id_page) AS posicion,
id_page,title,_fivetran_synced
from
{{ ref('paginas_encuestas') }} as page
where 
page.survey_id=411256991 
and page.position not in (1,10)
)



select 
ab.clave_pregunta as id_pregunta,
ab.id as id_opcion,
cd.opcion as area,
ab.opcion as opcion,
ab.posicion as posicion,
pg.title as titulo_pagina,
pg.id_page as id_pagina,
TO_DATE(pg._fivetran_synced) AS FECHA
from 
PR15 as ab
inner join 
PR14 as cd
on cd.posicion = ab.posicion
inner join 
PAG as pg
on pg.posicion = cd.posicion