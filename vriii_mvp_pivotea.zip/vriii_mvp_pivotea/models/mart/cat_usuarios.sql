--
--
{{
config(
materialized='table'
)
}}
--
--


 select 
 ID_RESPUESTA,
NOMBRE,
APELLIDOS,
CORREO,
to_date(fecha) as FECHA
from
{{ ref('tfr_pivotea_usuarios') }}
