--
--
{{
config(
materialized='table'
)
}}
--
--

select 
RENGLON_ID AS ID_TRAYECTORIA,
ID_PAGINA,
ID_PREGUNTA,
RENGLON AS TRAYECTORIA,
POSICION_RENGLON AS POSICION
from 
{{ ref('tfr_rel_preg_tray') }}
