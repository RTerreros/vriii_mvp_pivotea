--
--
select  
correo,
pregunta,
nvl(respuesta,opcion) as respuesta,
fecha
from (
select res.id_pagina,
res.id_respuesta,
correo,pregunta,
respuesta,
opcion,
res.fecha as fecha
from {{ ref('respuestas') }} as res
inner join {{ ref('cat_usuarios') }} usuario on 
res.id_respuesta = usuario.id_respuesta
inner join {{ ref('opciones') }} as opc
on opc.id_pregunta = res.id_pregunta
and opc.id_opcion = res.opcion_respuesta
inner join {{ ref('cat_preguntas') }} as pr
on res.id_pregunta = pr.id_pregunta
where res.id_pagina=49502655)