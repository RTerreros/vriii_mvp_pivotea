

select ab.correo,ab.trayectoria,ab.area,ab.puntaje,nombre_recomendaciones 
from (
select correo,
trayectoria,
id_trayectoria,
area,puntaje,
ROW_NUMBER() OVER(PARTITION BY correo ORDER BY puntaje DESC) AS top_posicion
from 
{{ ref('trayectorias_usuarios') }}) as ab
inner join 
{{ ref('rel_tray_cert') }} as cd
on 
ab.id_trayectoria = cd.id_trayectorias
where top_posicion < 4

