--
--
{{
config(
materialized='table'
)
}}
--
--


select cat_usuarios.correo,
id_trayectoria,
trayectoria,
id_pagina as id_area,
area,
sum(score) as puntaje
from 
{{ ref('rel_trayectoria_usuario') }}
inner join {{ ref('cat_usuarios') }}
on cat_usuarios.id_respuesta = rel_trayectoria_usuario.id_respuesta
group by correo,cat_usuarios.id_respuesta,trayectoria,area,id_trayectoria,id_area
order by correo, puntaje desc
