--
--
{{
config(
materialized='table'
)
}}
--
--

select 
ENC.ID as ID_ENCUESTA,
ENC.TITLE AS NOMBRE_ENCUESTA,
ENC.CATEGORY_ID AS CATEGORIA,
ENC_DET.STATUS,
ENC_DET.URL
from 
{{ ref('encuestas') }} AS ENC
INNER JOIN 
{{ ref('detalle_encuesta') }} AS ENC_DET
ON ENC_DET.SURVEY_ID=ENC.ID