--
--
{{
config(
materialized='table'
)
}}
--
--


select 
ID_ENCUESTA,
ID_PAGINA,
ID_PREGUNTA,
ID_RESPUESTA,
OPCION_RESPUESTA,
RENGLON_ID,
RESPUESTA,
TIEMPO_RESOLUCION,
TO_DATE(FECHA) AS FECHA
from 
{{ ref('tfr_respuestas') }}
where 
estatus_respuesta='completed'
