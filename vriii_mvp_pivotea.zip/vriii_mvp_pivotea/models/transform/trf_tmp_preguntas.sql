--
--
{{
config(
materialized='table'
)
}}
--
--
select cl_pr.ID as clave_pregunta,
page_enc.survey_id as id_encuesta,
page_enc.id_page as id_pagina,
enc.title as nombre_encuesta,
enc.category_id as tipo_encuesta,
cl_pr.family as tipo_pregunta,
cl_pr.subtype as subtipo_pregunta,
des_pr.heading as pregunta,
PARSE_JSON(cl_pr.structure_metadata):choices as opciones
from 
{{ ref('encuestas') }} as enc
inner join 
{{ ref('paginas_encuestas') }} as page_enc
on page_enc.survey_id = enc.id
inner join 
{{ ref('clave_preguntas') }} as cl_pr
on cl_pr.survey_page_id = page_enc.id_page
inner join {{ ref('desc_preguntas') }} des_pr
on des_pr.question_id = cl_pr.id



