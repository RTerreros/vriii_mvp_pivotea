--
--
{{
config(
materialized='table'
)
}}
--


select 
cl_pr.survey_page_id as ID_PAGINA,
cl_pr.id id_pregunta,
pr_sub.text as renglon,
pr_sub.position as posicion_renglon,
pr_sub.id as renglon_id
from 
{{ ref('sub_preguntas') }}  pr_sub
inner join
{{ ref('clave_preguntas') }}  as cl_pr
on cl_pr.id = pr_sub.question_id
inner join 
{{ ref('paginas_encuestas') }}  as page
on cl_pr.survey_page_id = page.id_page
inner join 
{{ ref('encuestas') }} as enc
on enc.id = page.survey_id
where enc.title ='Pivotea: Trazando mi futuro'
