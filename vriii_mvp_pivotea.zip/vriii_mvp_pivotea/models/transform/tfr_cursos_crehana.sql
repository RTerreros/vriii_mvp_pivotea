--
--
{{
config(
materialized='table'
)
}}
--
--
select 
* 
from 
{{ source('raw', 'CURSOS_CREHANA') }}