--
--
{{
config(
materialized='table'
)
}}
--
--

select  
enc.id as ID_ENCUESTA,
page_enc.id_page as ID_PAGINA,
desc_res.question_id as id_pregunta,
cl_res.id as id_respuesta,
enc.title as nombre_encuesta,
cl_res.total_time tiempo_resolucion,
cl_res.response_status estatus_respuesta,
desc_res.response_page_id as id_pagina_respuesta,
desc_res.choice_id as opcion_respuesta,
desc_res.row_id as renglon_id,
desc_res.text as respuesta,
desc_res._fivetran_synced as fecha
from 
{{ ref('encuestas') }} as enc
inner join 
{{ ref('paginas_encuestas') }} as page_enc
on page_enc.survey_id = enc.id
inner join
 {{ ref('clave_respuestas') }} as cl_res
on cl_res.survey_id = enc.id
inner join 
{{ ref('desc_respuestas') }} desc_res
on desc_res.response_id = cl_res.id
and desc_res.response_page_id=page_enc.id_page