--
--
{{
config(
materialized='table'
)
}}
--
--
--PIVOTEA_USUARIOS
---170530386 Correot
---170530387 Nombre
--170616739 Apellidos

select ID_RESPUESTA,
max(case when ID_PREGUNTA = 170530387 THEN respuesta end) as Nombre,
max(case when ID_PREGUNTA = 170616739 THEN respuesta end) as Apellidos,
max(case when ID_PREGUNTA = 170530386 THEN respuesta end) as Correo,
DATE_TRUNC('DAY', fecha) as fecha
FROM 
{{ ref('tfr_respuestas') }} AS TFR_RES
WHERE
TFR_RES.ID_PREGUNTA IN (170530386,170530387,170616739)
AND 
ESTATUS_RESPUESTA='completed'
group by
 ID_RESPUESTA,DATE_TRUNC('DAY', fecha)
