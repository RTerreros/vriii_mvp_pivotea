--
--
{{
config(
materialized='table'
)
}}
--
--
select 
* 
from 
{{ source('raw', 'CATEGORIA_CREHANA') }}