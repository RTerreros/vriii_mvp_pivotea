--
--
{{
config(
materialized='table'
)
}}
--
--
select
clave_pregunta,
TO_VARCHAR(PARSE_JSON(f.value):id) as ID,
TO_VARCHAR(PARSE_JSON(f.value):text) as OPCION,
TO_VARCHAR(PARSE_JSON(f.value):position) as POSICION,
f.value as fuente
from 
{{ ref('trf_tmp_preguntas') }},
lateral flatten(opciones) as f



