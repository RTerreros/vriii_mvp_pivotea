--
--
{{
config(
materialized='table'
)
}}
--
--
select 
* 
from 
{{ source('raw', 'TRAY_RECOMEND') }}