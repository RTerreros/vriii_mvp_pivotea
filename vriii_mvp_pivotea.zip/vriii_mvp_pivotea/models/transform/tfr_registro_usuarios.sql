--
--
{{
config(
materialized='table'
)
}}
--
--

--170598207	Nombre
--170598498	1Apellido
--170598587	2Apellido
--173258505	Ciudad
--170599255	Genero
--170599414	Fecha Nacimiento
--170599549	Correo
--170599741	Telefono
--170602239	Situacion
--170601204 Caladero



select
ID_RESPUESTA,
max(case when ID_PREGUNTA = 170598207 THEN respuesta end) as Nombre,
max(case when ID_PREGUNTA = 170598498 THEN respuesta end) as PrimerApellido,
max(case when ID_PREGUNTA = 170598587 THEN respuesta end) as SegundoApellido,
max(case when ID_PREGUNTA = 170599549 THEN respuesta end) as Correo,
max(case when ID_PREGUNTA = 173258505 THEN respuesta end) as Lugar,
max(case when ID_PREGUNTA = 170599255 THEN opcion end) as Genero,
max(case when ID_PREGUNTA = 170599414 THEN respuesta end) as Fecha_Nac,
max(case when ID_PREGUNTA = 170599741 THEN respuesta end) as Telefono,
max(case when ID_PREGUNTA = 170602239 THEN opcion end) as Situacion,
max(case when ID_PREGUNTA = 170601204 THEN opcion end) as Caladero,
ESTATUS_RESPUESTA,
DATE_TRUNC('DAY', fecha) as fecha
FROM 
{{ ref('tfr_respuestas') }}  AS TFR_RES
left join
{{ ref('tfr_preguntas_opc') }} as tfr_opc
on tfr_opc.id = tfr_res.opcion_respuesta
WHERE
TFR_RES.ID_PREGUNTA IN 
(170602239,170599741,170599549,170599414,170599255,173258505,170598587,170598498,170598207,170601204)
AND id_encuesta=516369607
group by ID_RESPUESTA,DATE_TRUNC('DAY', fecha),estatus_respuesta

